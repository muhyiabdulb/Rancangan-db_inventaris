--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tb_ruang DROP CONSTRAINT tb_ruang_pkey;
ALTER TABLE ONLY public.tb_petugas DROP CONSTRAINT tb_petugas_pkey;
ALTER TABLE ONLY public.tb_peminjaman DROP CONSTRAINT tb_peminjaman_pkey;
ALTER TABLE ONLY public.tb_pegawai DROP CONSTRAINT tb_pegawai_pkey;
ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE ONLY public.tb_jenis DROP CONSTRAINT tb_jenis_pkey;
ALTER TABLE ONLY public.tb_inventaris DROP CONSTRAINT tb_inventaris_pkey;
ALTER TABLE ONLY public.tb_detail_pinjam DROP CONSTRAINT tb_detail_pinjam_pkey;
ALTER TABLE public.tb_ruang ALTER COLUMN id_ruang DROP DEFAULT;
ALTER TABLE public.tb_petugas ALTER COLUMN id_petugas DROP DEFAULT;
ALTER TABLE public.tb_peminjaman ALTER COLUMN id_peminjaman DROP DEFAULT;
ALTER TABLE public.tb_pegawai ALTER COLUMN id_pegawai DROP DEFAULT;
ALTER TABLE public.tb_level ALTER COLUMN id_level DROP DEFAULT;
ALTER TABLE public.tb_jenis ALTER COLUMN id_jenis DROP DEFAULT;
ALTER TABLE public.tb_inventaris ALTER COLUMN id_inventaris DROP DEFAULT;
ALTER TABLE public.tb_detail_pinjam ALTER COLUMN id_detail_pinjam DROP DEFAULT;
DROP SEQUENCE public.tb_ruang_id_ruang_seq;
DROP TABLE public.tb_ruang;
DROP SEQUENCE public.tb_petugas_id_petugas_seq;
DROP TABLE public.tb_petugas;
DROP SEQUENCE public.tb_peminjaman_id_peminjaman_seq;
DROP TABLE public.tb_peminjaman;
DROP SEQUENCE public.tb_pegawai_id_pegawai_seq;
DROP TABLE public.tb_pegawai;
DROP SEQUENCE public.tb_level_id_level_seq;
DROP TABLE public.tb_level;
DROP SEQUENCE public.tb_jenis_id_jenis_seq;
DROP TABLE public.tb_jenis;
DROP SEQUENCE public.tb_inventaris_id_inventaris_seq;
DROP TABLE public.tb_inventaris;
DROP SEQUENCE public.tb_detail_pinjam_id_detail_pinjam_seq;
DROP TABLE public.tb_detail_pinjam;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tb_detail_pinjam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_detail_pinjam (
    id_detail_pinjam integer NOT NULL,
    id_inventaris integer,
    jumlah integer
);


ALTER TABLE tb_detail_pinjam OWNER TO postgres;

--
-- Name: tb_detail_pinjam_id_detail_pinjam_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_detail_pinjam_id_detail_pinjam_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_detail_pinjam_id_detail_pinjam_seq OWNER TO postgres;

--
-- Name: tb_detail_pinjam_id_detail_pinjam_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_detail_pinjam_id_detail_pinjam_seq OWNED BY tb_detail_pinjam.id_detail_pinjam;


--
-- Name: tb_inventaris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_inventaris (
    id_inventaris integer NOT NULL,
    nama character varying,
    kondisi character varying,
    keterangan text,
    jumlah integer,
    id_jenis integer,
    tanggal_register date,
    id_ruang integer,
    kode_inventaris character varying,
    id_petugas character varying
);


ALTER TABLE tb_inventaris OWNER TO postgres;

--
-- Name: tb_inventaris_id_inventaris_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_inventaris_id_inventaris_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_inventaris_id_inventaris_seq OWNER TO postgres;

--
-- Name: tb_inventaris_id_inventaris_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_inventaris_id_inventaris_seq OWNED BY tb_inventaris.id_inventaris;


--
-- Name: tb_jenis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_jenis (
    id_jenis integer NOT NULL,
    nama_jenis character varying,
    kode_jenis character varying,
    keterangan text
);


ALTER TABLE tb_jenis OWNER TO postgres;

--
-- Name: tb_jenis_id_jenis_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_jenis_id_jenis_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_jenis_id_jenis_seq OWNER TO postgres;

--
-- Name: tb_jenis_id_jenis_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_jenis_id_jenis_seq OWNED BY tb_jenis.id_jenis;


--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level integer NOT NULL,
    nama_level character varying
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_level_id_level_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_level_id_level_seq OWNER TO postgres;

--
-- Name: tb_level_id_level_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_level_id_level_seq OWNED BY tb_level.id_level;


--
-- Name: tb_pegawai; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_pegawai (
    id_pegawai integer NOT NULL,
    nama_pegawai character varying,
    nip character varying,
    alamat character varying
);


ALTER TABLE tb_pegawai OWNER TO postgres;

--
-- Name: tb_pegawai_id_pegawai_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_pegawai_id_pegawai_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_pegawai_id_pegawai_seq OWNER TO postgres;

--
-- Name: tb_pegawai_id_pegawai_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_pegawai_id_pegawai_seq OWNED BY tb_pegawai.id_pegawai;


--
-- Name: tb_peminjaman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_peminjaman (
    id_peminjaman integer NOT NULL,
    tanggal_pinjam date,
    tanggal_kembali date,
    status_peminjaman character varying,
    id_pegawai integer
);


ALTER TABLE tb_peminjaman OWNER TO postgres;

--
-- Name: tb_peminjaman_id_peminjaman_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_peminjaman_id_peminjaman_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_peminjaman_id_peminjaman_seq OWNER TO postgres;

--
-- Name: tb_peminjaman_id_peminjaman_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_peminjaman_id_peminjaman_seq OWNED BY tb_peminjaman.id_peminjaman;


--
-- Name: tb_petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_petugas (
    id_petugas integer NOT NULL,
    username character varying,
    password character varying,
    nama_petugas character varying,
    id_level integer
);


ALTER TABLE tb_petugas OWNER TO postgres;

--
-- Name: tb_petugas_id_petugas_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_petugas_id_petugas_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_petugas_id_petugas_seq OWNER TO postgres;

--
-- Name: tb_petugas_id_petugas_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_petugas_id_petugas_seq OWNED BY tb_petugas.id_petugas;


--
-- Name: tb_ruang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_ruang (
    id_ruang integer NOT NULL,
    nama_ruang character varying,
    kode_ruang character varying,
    keterangan text
);


ALTER TABLE tb_ruang OWNER TO postgres;

--
-- Name: tb_ruang_id_ruang_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tb_ruang_id_ruang_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tb_ruang_id_ruang_seq OWNER TO postgres;

--
-- Name: tb_ruang_id_ruang_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tb_ruang_id_ruang_seq OWNED BY tb_ruang.id_ruang;


--
-- Name: tb_detail_pinjam id_detail_pinjam; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_detail_pinjam ALTER COLUMN id_detail_pinjam SET DEFAULT nextval('tb_detail_pinjam_id_detail_pinjam_seq'::regclass);


--
-- Name: tb_inventaris id_inventaris; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_inventaris ALTER COLUMN id_inventaris SET DEFAULT nextval('tb_inventaris_id_inventaris_seq'::regclass);


--
-- Name: tb_jenis id_jenis; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_jenis ALTER COLUMN id_jenis SET DEFAULT nextval('tb_jenis_id_jenis_seq'::regclass);


--
-- Name: tb_level id_level; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level ALTER COLUMN id_level SET DEFAULT nextval('tb_level_id_level_seq'::regclass);


--
-- Name: tb_pegawai id_pegawai; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pegawai ALTER COLUMN id_pegawai SET DEFAULT nextval('tb_pegawai_id_pegawai_seq'::regclass);


--
-- Name: tb_peminjaman id_peminjaman; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_peminjaman ALTER COLUMN id_peminjaman SET DEFAULT nextval('tb_peminjaman_id_peminjaman_seq'::regclass);


--
-- Name: tb_petugas id_petugas; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_petugas ALTER COLUMN id_petugas SET DEFAULT nextval('tb_petugas_id_petugas_seq'::regclass);


--
-- Name: tb_ruang id_ruang; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_ruang ALTER COLUMN id_ruang SET DEFAULT nextval('tb_ruang_id_ruang_seq'::regclass);


--
-- Data for Name: tb_detail_pinjam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_detail_pinjam (id_detail_pinjam, id_inventaris, jumlah) FROM stdin;
\.
COPY tb_detail_pinjam (id_detail_pinjam, id_inventaris, jumlah) FROM '$$PATH$$/2873.dat';

--
-- Data for Name: tb_inventaris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM stdin;
\.
COPY tb_inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM '$$PATH$$/2879.dat';

--
-- Data for Name: tb_jenis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM stdin;
\.
COPY tb_jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM '$$PATH$$/2865.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2871.dat';

--
-- Data for Name: tb_pegawai; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_pegawai (id_pegawai, nama_pegawai, nip, alamat) FROM stdin;
\.
COPY tb_pegawai (id_pegawai, nama_pegawai, nip, alamat) FROM '$$PATH$$/2877.dat';

--
-- Data for Name: tb_peminjaman; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM stdin;
\.
COPY tb_peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM '$$PATH$$/2875.dat';

--
-- Data for Name: tb_petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_petugas (id_petugas, username, password, nama_petugas, id_level) FROM stdin;
\.
COPY tb_petugas (id_petugas, username, password, nama_petugas, id_level) FROM '$$PATH$$/2869.dat';

--
-- Data for Name: tb_ruang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM stdin;
\.
COPY tb_ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM '$$PATH$$/2867.dat';

--
-- Name: tb_detail_pinjam_id_detail_pinjam_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_detail_pinjam_id_detail_pinjam_seq', 1, false);


--
-- Name: tb_inventaris_id_inventaris_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_inventaris_id_inventaris_seq', 1, false);


--
-- Name: tb_jenis_id_jenis_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_jenis_id_jenis_seq', 1, false);


--
-- Name: tb_level_id_level_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_level_id_level_seq', 1, false);


--
-- Name: tb_pegawai_id_pegawai_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_pegawai_id_pegawai_seq', 1, false);


--
-- Name: tb_peminjaman_id_peminjaman_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_peminjaman_id_peminjaman_seq', 1, false);


--
-- Name: tb_petugas_id_petugas_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_petugas_id_petugas_seq', 1, false);


--
-- Name: tb_ruang_id_ruang_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tb_ruang_id_ruang_seq', 1, false);


--
-- Name: tb_detail_pinjam tb_detail_pinjam_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_detail_pinjam
    ADD CONSTRAINT tb_detail_pinjam_pkey PRIMARY KEY (id_detail_pinjam);


--
-- Name: tb_inventaris tb_inventaris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_inventaris
    ADD CONSTRAINT tb_inventaris_pkey PRIMARY KEY (id_inventaris);


--
-- Name: tb_jenis tb_jenis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_jenis
    ADD CONSTRAINT tb_jenis_pkey PRIMARY KEY (id_jenis);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- Name: tb_pegawai tb_pegawai_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pegawai
    ADD CONSTRAINT tb_pegawai_pkey PRIMARY KEY (id_pegawai);


--
-- Name: tb_peminjaman tb_peminjaman_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_peminjaman
    ADD CONSTRAINT tb_peminjaman_pkey PRIMARY KEY (id_peminjaman);


--
-- Name: tb_petugas tb_petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_petugas
    ADD CONSTRAINT tb_petugas_pkey PRIMARY KEY (id_petugas);


--
-- Name: tb_ruang tb_ruang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_ruang
    ADD CONSTRAINT tb_ruang_pkey PRIMARY KEY (id_ruang);


--
-- PostgreSQL database dump complete
--

